<?php

namespace App\Entity;

use App\Repository\EventRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

/**
 * Event Entity - Représente un événement
 * 
 * Les dates sont maintenant en DateTime (pas string) 
 * pour permettre les comparaisons et tris en base de données
 */
#[ORM\Entity(repositoryClass: EventRepository::class)]
#[ORM\Table(name: 'event')]
class Event
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private ?int $id = null;

    #[ORM\Column(type: 'string', length: 255)]
    private ?string $title = null;

    #[ORM\Column(type: 'text', nullable: true)]
    private ?string $description = null;

    #[ORM\Column(type: 'string', length: 255)]
    private ?string $location = null;

    /**
     * CORRIGÉ : Changé de string vers DATETIME_MUTABLE
     * Permet les comparaisons et tris en SQL
     */
    #[ORM\Column(type: Types::DATETIME_MUTABLE)]
    private ?\DateTimeInterface $date_start = null;

    /**
     * CORRIGÉ : Changé de string vers DATETIME_MUTABLE
     */
    #[ORM\Column(type: Types::DATETIME_MUTABLE)]
    private ?\DateTimeInterface $date_end = null;

    #[ORM\Column(type: 'integer')]
    private ?int $capacity = null;
    // ... après private $capacity;

    #[ORM\Column(nullable: true)]
    private ?float $price = null;

    public function getPrice(): ?float
    {
        return $this->price;
    }

    public function setPrice(?float $price): static
    {
        $this->price = $price;

        return $this;
    }

    // ... suite du fichier ...

    /**
     * @var Collection<int, Billet>
     */
    #[ORM\OneToMany(targetEntity: Billet::class, mappedBy: 'event', cascade: ['remove'])]
    private Collection $billets;

    public function __construct()
    {
        $this->billets = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    /**
     * CORRIGÉ : Le type paramètre reste int (pas string)
     */
    public function setId(int $id): static
    {
        $this->id = $id;
        return $this;
    }

    public function getTitle(): ?string
    {
        return $this->title;
    }

    public function setTitle(string $title): static
    {
        $this->title = $title;
        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(?string $description): static
    {
        $this->description = $description;
        return $this;
    }

    public function getLocation(): ?string
    {
        return $this->location;
    }

    public function setLocation(string $location): static
    {
        $this->location = $location;
        return $this;
    }

    /**
     * CORRIGÉ : Retourne DateTimeInterface (pas string)
     */
    public function getDateStart(): ?\DateTimeInterface
    {
        return $this->date_start;
    }

    /**
     * CORRIGÉ : Accepte DateTimeInterface (pas string)
     */
    public function setDateStart(\DateTimeInterface $date_start): static
    {
        $this->date_start = $date_start;
        return $this;
    }

    /**
     * CORRIGÉ : Retourne DateTimeInterface (pas string)
     */
    public function getDateEnd(): ?\DateTimeInterface
    {
        return $this->date_end;
    }

    /**
     * CORRIGÉ : Accepte DateTimeInterface (pas string)
     */
    public function setDateEnd(\DateTimeInterface $date_end): static
    {
        $this->date_end = $date_end;
        return $this;
    }

    public function getCapacity(): ?int
    {
        return $this->capacity;
    }

    public function setCapacity(int $capacity): static
    {
        $this->capacity = $capacity;
        return $this;
    }
    

    /**
     * @return Collection<int, Billet>
     */
    public function getBillets(): Collection
    {
        return $this->billets;
    }

    public function addBillet(Billet $billet): static
    {
        if (!$this->billets->contains($billet)) {
            $this->billets->add($billet);
            $billet->setEvent($this);
        }
        return $this;
    }

    public function removeBillet(Billet $billet): static
    {
        if ($this->billets->removeElement($billet)) {
            if ($billet->getEvent() === $this) {
                $billet->setEvent(null);
            }
        }
        return $this;
    }
}